# FAPCOIN API (Vercel-ready)

## Deploying to Vercel
1. Upload this folder (`fapcoin-api`) to a GitHub repo.
2. Go to https://vercel.com and create a new project.
3. Select the repo.
4. Deploy.

Your API endpoint will be:
`https://<your-vercel-project>.vercel.app/api/locks`
